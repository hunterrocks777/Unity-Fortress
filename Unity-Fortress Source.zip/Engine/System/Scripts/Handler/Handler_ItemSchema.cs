﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_ItemSchema : MonoBehaviour
{
    public TF_Class[] TF_Classes;
    public World_Maps[] TF_Maps;
}
[CreateAssetMenu(fileName = "tf_weapon"), System.Serializable]
public class Item_Weapon : ScriptableObject
{
    public string Base_Name = "Weapon";
    public string Base_Description = "Description";
    public Mesh Base_Mesh;
    public Texture Base_Texture;
    public Weapon_Combat Combat;
}
[System.Serializable]
public class Weapon_Combat 
{
    public bool Melee = false;
    public string SpecialTrait = "";
    public GameObject Projectile;
    public int Damage = 50;
    public int Magazine = 12;
    public int MagazineReserve = 36;
    public float AttackInterval = 0.25f;
    public float ReloadInterval = 1;
}