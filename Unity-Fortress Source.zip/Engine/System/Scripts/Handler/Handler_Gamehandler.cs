﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Handler_Gamehandler : MonoBehaviour
{
    public float TF_World_Timer = 60;
    public List<TF_PlayerList> TF_PlayerList;
    public bool TF_MatchStarted = false;

    public Vector3 TF_Objective_Org;
    public Vector3 TF_Objective_Grn;
    public List<MapEntity_SpawnPoint> TF_Spawns_Org = new List<MapEntity_SpawnPoint>();
    public List<MapEntity_SpawnPoint> TF_Spawns_Grn = new List<MapEntity_SpawnPoint>();

    public GameObject TF_NPC_Player;
    public GameObject TF_NPC_AI;

    [HideInInspector] public bool World_Pause = true;
    [HideInInspector] public string World_CurrentUI = "mainmenu";
    [HideInInspector] public string World_CurrentScene;

    [HideInInspector] public Handler_ItemSchema Items;
    [HideInInspector] public Handler_EffectsHandler effects;

    [HideInInspector] public GameObject mainCamera;
    [HideInInspector] public Entity_Player player;

    int handler_loadingStuff;
    void Start()
    {
        effects = FindObjectOfType<Handler_EffectsHandler>();
        Items = FindObjectOfType<Handler_ItemSchema>();
        mainCamera = GameObject.FindGameObjectWithTag("MainCamera");
        //Testing Purposes
    }
    private void Update()
    {
        TF_World_Timer -= Time.deltaTime;
        if (World_CurrentScene != "" && !player)
        {
            camera_freecamera();
        }
        if (World_Pause) 
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else 
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }
    public void camera_freecamera() 
    {
        
    }
    public void tf_newmatch(string map, int maxPlayers, string playerTeam)
    {
        StartCoroutine(tf_loadnewmatch(map, maxPlayers, playerTeam));
    }
    public IEnumerator tf_loadnewmatch(string map, int maxPlayers, string playerTeam)
    {
        StartCoroutine(gamehandler_map_load(map));
        yield return new WaitUntil(() => World_CurrentUI != "loading");
        gamehandler_tf_playerlist_generate(maxPlayers, playerTeam);
        if (playerTeam == "spec")
        {
            World_Pause = true;
            World_CurrentUI = "hud";
        }
        else
        {
            World_Pause = true;
            World_CurrentUI = "classselection";
        }
    }
    //Maps
    public void gamehandler_map_unload()
    {
        SceneManager.UnloadSceneAsync(World_CurrentScene);
        World_CurrentScene = "";
    }
    public IEnumerator gamehandler_map_load(string toLoad) 
    {
        World_CurrentUI = "loading";
        World_Pause = true;
        //Unload current level
        if (World_CurrentScene != "") //Only Unload if there is a level loaded
        {
            Debug.Log("Unloading " + World_CurrentScene + "...");
            AsyncOperation unloadLevel = SceneManager.UnloadSceneAsync(World_CurrentScene);
            yield return new WaitUntil(() => unloadLevel.isDone);
        }
        //Load New Level
        AsyncOperation loadLevel = SceneManager.LoadSceneAsync(toLoad, LoadSceneMode.Additive);
        yield return new WaitUntil(() => loadLevel.isDone);
        SceneManager.SetActiveScene(SceneManager.GetSceneByName(toLoad));
        World_CurrentScene = toLoad;
        yield return new WaitUntil(() => gamehandler_tf_generatespawn());
        World_CurrentUI = "";
        //Finish       
    }
    //Players
    public void gamehandler_tf_playerlist_generate(int amount, string playerTeam) 
    {
        bool newTeam = false; //false = org, true = green
        if (playerTeam == "grn")
        {
            newTeam = true;
        }
        if (playerTeam == "org")
        {
            newTeam = false;
        }
        //Generate playerlist
        for (int npc = 0; npc < amount; npc++)
        {
            TF_PlayerList mob = new TF_PlayerList();
            mob.Player_Kills = 0;
            mob.Player_Deaths = 0;
            if (npc == 0 && playerTeam != "spec")
            {
                //If the player is included in the match, include him here
                mob.Player_Mob = Instantiate(TF_NPC_Player);
                player = mob.Player_Mob.GetComponent<Entity_Player>(); //Set it so the player is here
            }
            else 
            {
                mob.Player_Mob = Instantiate(TF_NPC_AI);
            }
            if (newTeam)
            {
                mob.Player_Mob.GetComponent<Entity_Mob_Team>().Team = "grn";
            }
            else
            {
                mob.Player_Mob.GetComponent<Entity_Mob_Team>().Team = "org";
            }
            newTeam = !newTeam;
            mob.Player_Mob.GetComponent<Entity_Mob>().Mob_Setup();
            TF_PlayerList.Add(mob);
        }
    }
    public bool gamehandler_tf_generatespawn() 
    {
        MapEntity_SpawnPoint[] Spawns = FindObjectsOfType<MapEntity_SpawnPoint>();
        for (int a = 0; a < Spawns.Length; a++)
        {
            if (Spawns[a].Team == "org")
            {
                TF_Spawns_Org.Add(Spawns[a]);
            }
            if (Spawns[a].Team == "grn")
            {
                TF_Spawns_Grn.Add(Spawns[a]);
            }
        }
        return true;
    }
    public void gamehandler_tf_player_chooseclass(int newclass)
    {
        player.GetComponent<Entity_Mob>().myclass = Items.TF_Classes[newclass];
        player.GetComponent<Entity_Mob>().Mob_RecongfigureClass();
        TF_MatchStarted = true;
        World_Pause = false;
        World_CurrentUI = "hud";
    }
}
[CreateAssetMenu(fileName = "tf_class"), System.Serializable]
public class TF_Class : ScriptableObject
{
    public string Class_Name = "Class";
    public string Class_Description = "Class Description";
    public int Class_Health = 125;
    [Range(0.1f, 2.0f)] public float Class_Speed = 1.0f;
    public Item_Weapon Class_Primary;
    public Item_Weapon Class_Secondary;
    public Item_Weapon Class_Melee;
    public Item_Weapon Class_Special;
    public Texture Class_Orange;
    public Texture Class_Green;
}
[System.Serializable]
public class Mob_Weapons
{
    public int MobCurrentWeapon;
    public Item_Weapon[] MobWeapons;
}
[System.Serializable]
public class World_Maps 
{
    public string Map_Name;
    public Sprite Map_Image;
}
[System.Serializable]
public class TF_PlayerList
{
    public string Player_Name;
    public string Player_Team;
    public GameObject Player_Mob;
    public TF_Class Player_Class;
    public int Player_Kills;
    public int Player_Deaths;
}