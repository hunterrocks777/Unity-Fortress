﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_EffectsHandler : MonoBehaviour
{
    public GameObject[] Effects;
    public void SpawnEffect(string effectName, Vector3 pos, Quaternion rot) 
    {
        int spawn = 0;
        for (int effect = 0; effect < Effects.Length; effect++)
        {
            if (Effects[effect].name == effectName)
            {
                spawn = effect;
                break;
            }
        }
        Instantiate(Effects[spawn], pos, rot);
    }
}
