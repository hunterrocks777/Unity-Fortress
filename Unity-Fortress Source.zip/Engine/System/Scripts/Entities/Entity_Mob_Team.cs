﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Mob_Team : MonoBehaviour
{
    public string Team;
}
