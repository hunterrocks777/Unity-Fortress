﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Mob_Render : MonoBehaviour
{
    public Texture Mob_Skin;
    public SkinnedMeshRenderer Mob_SMR;
    public GameObject Mob_Weapon;
    // Update is called once per frame
    void Update()
    {
        Mob_SMR.material.mainTexture = Mob_Skin;
    }
}
