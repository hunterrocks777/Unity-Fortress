﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Mob : MonoBehaviour
{
    public TF_Class myclass;
    public int Mob_MaxHP = 125;
    public int Mob_HP = 125;
    public float Mob_Speed;
    public Mob_Weapons Mob_Weapon;
    public Entity_Mob_Render Mob_Render;
    public Entity_Mob_Team Mob_Team;

    //Hidden Variables
    public Vector2 Mob_Look;
    [HideInInspector] public bool Mob_CanUseWeapon = true;
    [HideInInspector] public Vector3 Mob_Velocity;
    [HideInInspector] public CharacterController Mob_Char_Controller;

    //Player Variables
    Handler_Gamehandler handler;

    // Start is called before the first frame update
    void Awake()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        Mob_Char_Controller = GetComponent<CharacterController>();
        Mob_Render = GetComponentInChildren<Entity_Mob_Render>();
        Mob_Team = GetComponent<Entity_Mob_Team>();
    }
    public void Mob_Setup() 
    {
        myclass = handler.Items.TF_Classes[Random.Range(0, 8)];
        Mob_MaxHP = myclass.Class_Health;
        Mob_HP = Mob_MaxHP;
        Mob_Speed = myclass.Class_Speed * 7.5f;
        if (Mob_Team.Team == "grn")
        {
            Mob_Render.Mob_Skin = myclass.Class_Green;
            transform.position = handler.TF_Spawns_Grn[Random.Range(0, handler.TF_Spawns_Grn.Count)].transform.position;
        }
        else 
        {
            Mob_Render.Mob_Skin = myclass.Class_Orange;
            transform.position = handler.TF_Spawns_Org[Random.Range(0, handler.TF_Spawns_Org.Count)].transform.position;
        }
        //Weapons
        Mob_Weapon.MobWeapons = new Item_Weapon[4];
        Mob_Weapon.MobWeapons[0] = myclass.Class_Primary;
        Mob_Weapon.MobWeapons[1] = myclass.Class_Secondary;
        Mob_Weapon.MobWeapons[2] = myclass.Class_Melee;
        Mob_Weapon.MobWeapons[3] = myclass.Class_Special;
    }
    public void Mob_RecongfigureClass() 
    {
        Mob_MaxHP = myclass.Class_Health;
        Mob_HP = Mob_MaxHP;
        Mob_Speed = myclass.Class_Speed * 7.5f;
        if (Mob_Team.Team == "grn")
        {
            Mob_Render.Mob_Skin = myclass.Class_Green;
            transform.position = handler.TF_Spawns_Grn[Random.Range(0, handler.TF_Spawns_Grn.Count)].transform.position;
        }
        else
        {
            Mob_Render.Mob_Skin = myclass.Class_Orange;
            transform.position = handler.TF_Spawns_Org[Random.Range(0, handler.TF_Spawns_Org.Count)].transform.position;
        }
        //Weapons
        Mob_Weapon.MobWeapons = new Item_Weapon[4];
        Mob_Weapon.MobWeapons[0] = myclass.Class_Primary;
        Mob_Weapon.MobWeapons[1] = myclass.Class_Secondary;
        Mob_Weapon.MobWeapons[2] = myclass.Class_Melee;
        Mob_Weapon.MobWeapons[3] = myclass.Class_Special;
    }
    public void Mob_Respawn() 
    {
        if (Mob_Team.Team == "grn")
        {
            Mob_Render.Mob_Skin = myclass.Class_Green;
            transform.position = handler.TF_Spawns_Grn[Random.Range(0, handler.TF_Spawns_Grn.Count)].transform.position;
        }
        else
        {
            Mob_Render.Mob_Skin = myclass.Class_Orange;
            transform.position = handler.TF_Spawns_Org[Random.Range(0, handler.TF_Spawns_Org.Count)].transform.position;
        }
    }
    // Update is called once per frame
    public void Mob_Movement() 
    {
        Mob_Char_Controller.Move(Mob_Velocity * Time.deltaTime);
    }
    public void Mob_Combat_Fire() 
    {
        Debug.Log(name + " fired their weapon!");
        Mob_CanUseWeapon = false;
        if (Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.Projectile != null)
        {
            //Projectile based
            Instantiate(Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.Projectile, transform.position + transform.forward + transform.right / 2, transform.rotation * Quaternion.Euler(Mob_Look.x, Mob_Look.y, 0));
        }
        else 
        {
            Ray ray = new Ray(transform.position + transform.forward + transform.right * 0.5f, Mob_Look);
            RaycastHit hit = new RaycastHit();

            if (!Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.Melee) 
            {
                if (Physics.Raycast(ray, out hit, 50))
                {
                    Debug.Log("hit something!" + hit.transform.name);
                    if (hit.transform.GetComponent<Entity_Mob>()) 
                    {
                        hit.transform.GetComponent<Entity_Mob>().Mob_HP -= Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.Damage;
                        handler.effects.SpawnEffect("effect_blood", hit.point, hit.transform.rotation);
                    }
                }
            }
            else 
            {
                if (Physics.Raycast(ray, out hit, 5))
                {
                    if (hit.transform.GetComponent<Entity_Mob>())
                    {
                        hit.transform.GetComponent<Entity_Mob>().Mob_HP -= Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.Damage;
                        handler.effects.SpawnEffect("effect_blood", hit.point, hit.transform.rotation);
                    }
                }
            }
        }
        Invoke("Mob_Combat_Reset", Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.AttackInterval);
    }
    public void Mob_Combat_Reload()
    {
        Mob_CanUseWeapon = false;
        //Fire stuff here
        Invoke("Mob_Combat_Reset", Mob_Weapon.MobWeapons[Mob_Weapon.MobCurrentWeapon].Combat.ReloadInterval);
    }
    public void Mob_Combat_Swap()
    {
        Mob_CanUseWeapon = false;
        //Fire stuff here
        Invoke("Mob_Combat_Reset", 0.5f);
    }
    public void Mob_Combat_Reset() 
    {
        Mob_CanUseWeapon = true;
    }
}
