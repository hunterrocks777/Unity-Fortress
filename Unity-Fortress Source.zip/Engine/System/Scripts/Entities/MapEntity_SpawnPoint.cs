﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEntity_SpawnPoint : MonoBehaviour
{
    public string Team = "grn";
}
