﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Player : MonoBehaviour
{
    Entity_Mob mob;
    Handler_Gamehandler handler;
    // Start is called before the first frame update
    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        mob = GetComponent<Entity_Mob>();
        mob.Mob_Render.Mob_SMR.enabled = false;
    }

    private void Update()
    {
        Debug.DrawRay(transform.position + transform.forward + transform.right * 0.5f, mob.Mob_Look, Color.yellow, 1);
        if (handler.TF_MatchStarted)
        {
            Player_Movement();
            Player_Camera();
            Player_Combat();
        }
    }
    private void LateUpdate()
    {
        Player_Viewmodel();
    }
    public void Player_Combat() 
    {
        if (mob.Mob_CanUseWeapon) 
        {
            if (Input.GetKey(KeyCode.Mouse0)) 
            {
                mob.Mob_Combat_Fire();
            }
            if (Input.GetKey(KeyCode.R))
            {
                mob.Mob_Combat_Reload();
            }
        }
    }
    public void Player_Movement() 
    {
        float y = mob.Mob_Velocity.y;
        mob.Mob_Velocity = (transform.forward * Input.GetAxis("Vertical") * mob.Mob_Speed) + (transform.right * Input.GetAxis("Horizontal") * mob.Mob_Speed);
        mob.Mob_Velocity.y = y;
        if (mob.Mob_Char_Controller.isGrounded)
        {
            mob.Mob_Velocity.y = 0;
            if (Input.GetKey(KeyCode.Space))
            {
                mob.Mob_Velocity.y = 10;
            }
        }
        mob.Mob_Velocity.y += Physics.gravity.y * Time.deltaTime;
        mob.Mob_Movement();
    }
    public void Player_Camera() 
    {
        mob.Mob_Look.x += Input.GetAxis("Mouse Y") * -4;
        mob.Mob_Look.x = Mathf.Clamp(mob.Mob_Look.x, -80, 80);
        mob.Mob_Look.y += Input.GetAxis("Mouse X") * 4;
        //Actually move the camera
        handler.mainCamera.transform.position = transform.position + new Vector3(0, 0.6f, 0);
        transform.rotation = Quaternion.Euler(0, mob.Mob_Look.y, 0);
        handler.mainCamera.transform.rotation = Quaternion.Euler(mob.Mob_Look.x, mob.Mob_Look.y, 0);
    }
    public void Player_Viewmodel() 
    {
        //mob.Mob_Render.transform.rotation = Quaternion.Euler(cameraRot.x, cameraRot.y, 0);
        //mob.Mob_Render.transform.position = handler.mainCamera.transform.position;
    }
}
