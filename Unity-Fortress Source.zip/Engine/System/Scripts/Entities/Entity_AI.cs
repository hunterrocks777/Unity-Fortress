﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class Entity_AI : MonoBehaviour
{
    [HideInInspector] public NavMeshAgent ai_agent;
    Entity_Mob mob;
    //AI Variables
    string ai_behavior;
    Vector3 ai_destination;
    GameObject ai_target;
    Handler_Gamehandler handler;
    // Start is called before the first frame update
    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        mob = GetComponent<Entity_Mob>();
        ai_agent = GetComponent<NavMeshAgent>();
    }
    // Update is called once per frame
    void Update()
    {
        if (handler.TF_MatchStarted)
        {
            if (ai_target)
            {
                ai_destination = ai_target.transform.position;
            }
            else
            {
                if (mob.Mob_Team.Team == "grn")
                {
                    ai_destination = handler.TF_Objective_Grn;
                }
                if (mob.Mob_Team.Team == "org")
                {
                    ai_destination = handler.TF_Objective_Org;
                }
            }
            AI_CalculateDestination();
        }
    }
    public void AI_CalculateDestination() 
    {
        ai_agent.SetDestination(ai_destination);
        ai_agent.speed = mob.Mob_Speed;
        ai_agent.stoppingDistance = Random.Range(2, 20);
    }
}
