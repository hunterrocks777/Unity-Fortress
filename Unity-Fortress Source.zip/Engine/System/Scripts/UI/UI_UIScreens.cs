﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UI_UIScreens : MonoBehaviour
{
    public string UI_CurrentCanvas;
    public Canvas[] UI_Canvases;
    public bool MainUI;

    Handler_Gamehandler handler;

    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
    }
    public void UI_ChangeScreen(string newScreen) 
    {
        UI_CurrentCanvas = newScreen;
    }
    // Update is called once per frame
    void Update()
    {
        if (MainUI) 
        {
            UI_CurrentCanvas = handler.World_CurrentUI;
        }
        foreach (Canvas can in UI_Canvases)
        {
            if (can.name == UI_CurrentCanvas)
            {
                can.enabled = true;
            }
            else
            {
                can.enabled = false;
            }
        }
    }
}
