﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_MainMenu_MapSelection : MonoBehaviour
{
    Handler_Gamehandler handler;
    Handler_ItemSchema items;
    public Slider UI_SliderMaxPlayers;
    public Dropdown UI_DropdownMaps;
    public Dropdown UI_DropdownAILevel;
    public Dropdown UI_DropdownPlayerteam;
    private void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        items = FindObjectOfType<Handler_ItemSchema>();
        LoadMapSelectionDropdown();
    }
    public void LoadMapSelectionDropdown() 
    {
        List<Dropdown.OptionData> maps_dropdown = new List<Dropdown.OptionData>();
        for (int a = 0; a < items.TF_Maps.Length; a++)
        {
            maps_dropdown.Add(new Dropdown.OptionData(items.TF_Maps[a].Map_Name, items.TF_Maps[a].Map_Image));
        }
        UI_DropdownMaps.AddOptions(maps_dropdown);
    }
    public void MapSelection_Play() 
    {
        string playerTeam = "spec";
        if (UI_DropdownPlayerteam.value == 0)
        {
            playerTeam = "spec";
        }
        if (UI_DropdownPlayerteam.value == 1)
        {
            playerTeam = "org";
        }
        if (UI_DropdownPlayerteam.value == 2)
        {
            playerTeam = "grn";
        }
        handler.tf_newmatch(UI_DropdownMaps.options[UI_DropdownMaps.value].text, Mathf.RoundToInt(UI_SliderMaxPlayers.value), playerTeam);
    }
}
